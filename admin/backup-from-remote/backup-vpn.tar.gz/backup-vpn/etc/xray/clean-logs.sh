#!/bin/bash

# Hapus atau kosongkan log Xray
truncate -s 0 /var/log/xray/error.log
truncate -s 0 /var/log/xray/access.log

# Hapus log rotasi NGINX
rm -f /var/log/nginx/access.log.1

# Kosongkan log aktif NGINX
truncate -s 0 /var/log/nginx/access.log

# Restart service untuk memastikan tetap jalan normal
systemctl restart xray
systemctl restart nginx
echo "Clean logs run at $(date)" >> /var/log/clean-logs.log

