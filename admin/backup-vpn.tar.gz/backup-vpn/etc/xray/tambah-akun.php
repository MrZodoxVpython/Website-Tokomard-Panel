<?php
if ($argc < 5) {
    echo "❌ Parameter tidak lengkap!\n";
    echo "Gunakan: php tambah-akun.php username expired protokol key\n";
    exit(1);
}

$username = $argv[1];
$expired  = hitungTanggalExpired($argv[2]);
$proto    = $argv[3];
$key      = $argv[4];

$configPath = '/etc/xray/config.json';

function insertIntoTag($configPath, $tag, $commentLine, $jsonLine) {
    if (!file_exists($configPath)) return false;
    $lines = file($configPath);
    foreach ($lines as $i => $line) {
        if (strpos($line, "#$tag") !== false) {
            array_splice($lines, $i + 1, 0, [$commentLine . "\n", $jsonLine . "\n"]);
            file_put_contents($configPath, implode("\n", array_map('rtrim', $lines)) . "\n");
            return true;
        }
    }
    return false;
}

function hitungTanggalExpired($expiredInput) {
    if (preg_match('/^\d+$/', $expiredInput)) {
        return date('Y-m-d', strtotime("+$expiredInput days"));
    }
    return $expiredInput;
}

$prefixMap = [
    'vmess'       => '###',
    'vless'       => '#&',
    'trojan'      => '#!',
    'shadowsocks' => '#$'
];

$tagMap = [
    'vmess'       => ['vmess', 'vmessgrpc'],
    'vless'       => ['vless', 'vlessgrpc'],
    'trojan'      => ['trojanws', 'trojangrpc'],
    'shadowsocks' => ['ssws', 'ssgrpc']
];

if (!isset($prefixMap[$proto])) {
    echo "❌ Protokol tidak dikenali\n";
    exit(1);
}

$commentPrefix = $prefixMap[$proto];
$commentLine   = "$commentPrefix $username $expired";

switch ($proto) {
    case 'vmess':
        $jsonLine = "},{\"id\": \"$key\", \"alterId\": 0, \"email\": \"$username\"";
        break;
    case 'vless':
        $jsonLine = "},{\"id\": \"$key\", \"email\": \"$username\"";
        break;
    case 'trojan':
        $jsonLine = "},{\"password\": \"$key\", \"email\": \"$username\"";
        break;
    case 'shadowsocks':
        $jsonLine = "},{\"password\": \"$key\", \"method\": \"aes-128-gcm\", \"email\": \"$username\"";
        break;
    default:
        echo "❌ Format protokol tidak valid\n";
        exit(1);
}

$success = true;
foreach ($tagMap[$proto] as $tag) {
    if (!insertIntoTag($configPath, $tag, $commentLine, $jsonLine) && $success) {
        $success = false;
    }
}

if ($success) {
    shell_exec('systemctl restart xray');
    $domain = trim(@file_get_contents('/etc/xray/domain'));
    $tls = "443";
    $ntls = "80";
    $grpcService = $proto . "-grpc";
    $path = "/$proto-ws";

    echo '<div style="
        background-color: #111827;
        color: #00ff7f;
        padding: 1em;
        border-radius: 10px;
        overflow-x: auto;
        white-space: pre;
        max-width: 100%;
        border: 2px solid #f97316;
    ">';
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n";
    echo "          " . strtoupper($proto) . " ACCOUNT           \n";
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n";
    echo "Remarks        : $username\n";
    echo "Host/IP        : $domain\n";
    echo "Wildcard       : (bug.com).$domain\n";
    echo "Port TLS       : $tls\n";
    echo "Port none TLS  : $ntls\n";
    echo "Port gRPC      : $tls\n";
    echo ($proto === 'vmess' || $proto === 'vless') ? "UUID           : $key\n" : "Password       : $key\n";
    echo "Path           : $path\n";
    echo "ServiceName    : $grpcService\n";
    echo "Expired On     : $expired\n";
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n";

    switch ($proto) {
        case 'vmess':
            $vmessLink = "vmess://" . base64_encode(json_encode([
                "v" => "2",
                "ps" => $username,
                "add" => $domain,
                "port" => $tls,
                "id" => $key,
                "aid" => "0",
                "net" => "ws",
                "type" => "none",
                "host" => "",
                "path" => $path,
                "tls" => "tls"
            ]));
            echo "Link TLS       : $vmessLink\n";
            break;

        case 'vless':
            echo "Link TLS       : vless://$key@$domain:$tls?path=$path&security=tls&type=ws#$username\n";
            echo "Link non-TLS   : vless://$key@$domain:$ntls?path=$path&security=none&type=ws#$username\n";
            echo "Link gRPC      : vless://$key@$domain:$tls?mode=gun&security=tls&type=grpc&serviceName=$grpcService#$username\n";
            break;

        case 'trojan':
            echo "Link TLS       : trojan://$key@$domain:$tls?path=$path&security=tls&type=ws#$username\n";
            echo "Link non-TLS   : trojan://$key@$domain:$ntls?path=$path&security=none&type=ws#$username\n";
            echo "Link gRPC      : trojan://$key@$domain:$tls?mode=gun&security=tls&type=grpc&serviceName=$grpcService#$username\n";
            break;

        case 'shadowsocks':
            $encoded = base64_encode("aes-128-gcm:$key");
            echo "Link SS (TLS)  : ss://$encoded@$domain:$tls#$username\n";
            echo "Link SS (Non)  : ss://$encoded@$domain:$ntls#$username\n";
            break;
    }

    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n";
    echo '</div>';
} else {
    echo "❌ Gagal menambahkan akun ke salah satu tag.\n";
}
