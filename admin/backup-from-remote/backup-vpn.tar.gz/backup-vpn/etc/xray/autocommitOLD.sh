#!/bin/bash

REPO_PATH="/var/www/html/Website-Tokomard-Panel"  # Ganti dengan direktori proyek Git kamu
cd "$REPO_PATH" || exit

echo "👀 Watching for changes in $REPO_PATH ..."

while inotifywait -e modify,create,delete -r .; do
    git add .
    git commit -m "Auto commit developing progress By Benjamin.Wickman : $(date '+%Y-%m-%d %H:%M:%S')"
    git push origin main  # Ganti 'main' jika branch kamu berbeda
    echo "✅ Auto-committed and pushed at $(date)"
done
