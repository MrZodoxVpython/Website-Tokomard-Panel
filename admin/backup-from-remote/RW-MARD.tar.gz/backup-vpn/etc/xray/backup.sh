#!/bin/bash

# === KONFIGURASI ===
VPS_NAME="RW-MARD"      # ⬅ UBAH SESUAI VPS
TOKEN_FILE="/tmp/token.json"
RCLONE_CONF="/root/.config/rclone/rclone.conf"
BACKUP_DIR="/root/backup-vpn/etc"
BACKUP_FILE="/root/backup-vpn.tar.gz"
WEB_DEST="/var/www/html/Website-Tokomard-Panel/admin/backup-vpn.tar.gz"  # Opsional

# === CEK TOKEN ===
if [ ! -f "$TOKEN_FILE" ]; then
    echo "❌ Token file tidak ditemukan!"
    exit 1
fi
if ! jq .access_token "$TOKEN_FILE" &>/dev/null; then
    echo "❌ Token JSON tidak valid atau rusak!"
    exit 1
fi

# === INSTALL RCLONE JIKA BELUM ===
echo "📦 Menjalankan proses backup..."
if ! command -v rclone &>/dev/null; then
    echo "📥 Menginstall rclone..."
    curl https://rclone.org/install.sh | bash || {
        echo "❌ Gagal menginstal rclone!"
        exit 1
    }
fi

# === TULIS KONFIG RCLONE ===
mkdir -p "$(dirname "$RCLONE_CONF")"
cat > "$RCLONE_CONF" <<EOF
[GDRIVE]
type = drive
scope = drive
token = $(cat "$TOKEN_FILE")
team_drive =
EOF

# === BACKUP FILE ===
rm -rf "$BACKUP_DIR"
mkdir -p "$BACKUP_DIR"
cp -r /etc/xray "$BACKUP_DIR/" 2>/dev/null || echo "⚠ /etc/xray tidak ditemukan"
cp -r /etc/v2ray "$BACKUP_DIR/" 2>/dev/null || echo "⚠ /etc/v2ray tidak ditemukan"
cp -r /etc/passwd /etc/shadow /etc/group /etc/gshadow "$BACKUP_DIR/" 2>/dev/null
cp -r /etc/cron.d "$BACKUP_DIR/" 2>/dev/null
cp -r /etc/ssh "$BACKUP_DIR/" 2>/dev/null
cp -r /etc/systemd/system "$BACKUP_DIR/" 2>/dev/null

# === BUAT TAR.GZ ===
echo "🗜 Membuat arsip backup..."
tar -czf "$BACKUP_FILE" -C /root backup-vpn
if [ ! -f "$BACKUP_FILE" ]; then
    echo "❌ File backup gagal dibuat."
    ls -lah /root/backup-vpn
    exit 1
fi

# === UPLOAD KE GOOGLE DRIVE ===
echo "☁ Mengupload ke Google Drive..."
if rclone --config="$RCLONE_CONF" copy "$BACKUP_FILE" "GDRIVE:/TOKOMARD/Backup-VPS/$VPS_NAME" --progress 2>&1; then
    echo "✅ Upload ke Google Drive berhasil!"
else
    echo "❌ Upload ke Google Drive gagal!"
fi

# === COPY KE WEB (OPSIONAL) ===
# === KIRIM KE VPS PANEL (JIKA BUKAN PANEL) ===
PANEL_IP="178.128.60.185"
REMOTE_PATH="/var/www/html/Website-Tokomard-Panel/admin/backup-from-remote/${VPS_NAME}.tar.gz"

echo "📤 Mengirim file ke VPS panel..."

scp -o StrictHostKeyChecking=no "$BACKUP_FILE" "root@$PANEL_IP:$REMOTE_PATH" && \
ssh root@$PANEL_IP "chmod 644 $REMOTE_PATH" && \
echo "✅ Backup tersedia di Web Panel: http://$PANEL_IP/Website-Tokomard-Panel/admin/backup-from-remote/${VPS_NAME}.tar.gz" || \
echo "❌ Gagal mengirim file backup ke VPS panel!"

# === BERSIH-BERSIH ===
rm -rf "$BACKUP_DIR" "$BACKUP_FILE"
echo "✅ Backup selesai!"

