#!/bin/bash

today=$(date +%Y-%m-%d)

# Ambil semua user local
awk -F: '$3 >= 1000 && $3 < 65534 { print $1 }' /etc/passwd | while read user; do
    exp=$(chage -l "$user" | grep "Account expires" | cut -d: -f2 | xargs)

    if [[ "$exp" != "never" && "$(date -d "$exp" +%Y-%m-%d)" < "$today" ]]; then
        echo "Menghapus user expired: $user"
        userdel -f "$user"
    fi
done

