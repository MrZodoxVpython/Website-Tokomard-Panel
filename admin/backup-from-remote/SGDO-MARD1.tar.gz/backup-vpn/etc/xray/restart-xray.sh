#!/bin/bash
systemctl restart xray

